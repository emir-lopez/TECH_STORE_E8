"""Punto de arranque único de TechStore U4.

- Visual Studio (flecha verde): ejecuta este archivo y abre Swagger en el navegador.
- IIS (HttpPlatformHandler): web.config lo ejecuta y el puerto llega en HTTP_PLATFORM_PORT.
- Consola: python run.py
"""
import os
import threading
import webbrowser

try:
    import uvicorn
except ImportError:  # entorno virtual sin dependencias instaladas
    raise SystemExit("Falta instalar dependencias. Ejecuta instalar.bat (o: pip install -r requirements.txt)")

from app.api import app  # el objeto FastAPI definido en app/api.py

# IIS asigna el puerto por variable de entorno; en local se usa 8000
EN_IIS = "HTTP_PLATFORM_PORT" in os.environ
PORT = int(os.environ.get("HTTP_PLATFORM_PORT") or os.environ.get("PORT") or 8000)
HOST = "127.0.0.1"

if __name__ == "__main__":
    if not EN_IIS:
        # Abre Swagger 1.5 s después de arrancar (solo en desarrollo)
        threading.Timer(1.5, lambda: webbrowser.open(f"http://{HOST}:{PORT}/docs")).start()
    uvicorn.run(app, host=HOST, port=PORT)
