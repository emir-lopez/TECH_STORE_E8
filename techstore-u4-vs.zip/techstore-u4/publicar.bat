@echo off
REM Copia a .\publish solo lo necesario para IIS (sin tests, docs ni .venv)
cd /d "%~dp0"
if exist publish rmdir /s /q publish
mkdir publish
robocopy app publish\app /E /XD __pycache__ >nul
robocopy datos publish\datos /E >nul
copy /y cargar_csv.py publish\ >nul
copy /y run.py publish\ >nul
copy /y web.config publish\ >nul
copy /y requirements.txt publish\ >nul
mkdir publish\logs
echo Carpeta publish lista. Ver instrucciones de IIS en LEEME_VS_IIS.txt
pause
