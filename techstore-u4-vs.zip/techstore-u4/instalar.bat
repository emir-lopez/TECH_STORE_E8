@echo off
REM Crea el entorno virtual .venv e instala las dependencias (solo la primera vez)
cd /d "%~dp0"
if not exist .venv (py -3 -m venv .venv || python -m venv .venv)
.venv\Scripts\python.exe -m pip install -r requirements.txt
echo.
echo Listo. Abre TechStoreU4.sln en Visual Studio y presiona la flecha verde.
pause
